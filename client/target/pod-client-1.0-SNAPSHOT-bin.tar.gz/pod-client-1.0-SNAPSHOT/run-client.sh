#!/bin/bash

java -cp 'lib/jars/*' "pod.client.Client" $*


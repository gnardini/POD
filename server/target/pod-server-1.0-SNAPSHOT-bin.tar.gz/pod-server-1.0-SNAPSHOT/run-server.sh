#!/bin/bash

java  -cp 'lib/jars/*' "pod.server.Server" $*

